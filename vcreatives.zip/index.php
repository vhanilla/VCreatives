<?php
session_start();
$isLoggedIn = isset($_SESSION['user']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>A Brilliant Vision</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=1">
    <style>
    .cafe-row {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        gap: 0;
        margin-top: 18px;
        margin-bottom: 10px;
    }
    .cafe-menu-img {
        width: 220px;
        height: auto;
        border-radius: 13px;
        box-shadow: 0 2px 16px 0 rgba(80,50,20,0.08);
        cursor: pointer;
        transition: box-shadow 0.13s, transform 0.13s;
        margin: 0;
        border: none;
        padding: 0;
        background: #fffdfa;
        object-fit: cover;
        display: block;
    }
    .cafe-menu-img:active, .cafe-menu-img:focus, .cafe-menu-img:hover {
        box-shadow: 0 6px 24px 0 rgba(80,50,20,0.16);
        transform: scale(1.045);
        z-index: 2;
    }
    @media (max-width:1000px) {
        .cafe-row { flex-wrap: wrap; }
        .cafe-menu-img { width: 99vw; max-width: 370px; margin-bottom: 10px; }
    }
    .menu-modal {
        display: none;
        position: fixed;
        z-index: 9999;
        left: 0; top: 0; width: 100vw; height: 100vh;
        background: rgba(25, 18, 12, 0.86);
        justify-content: center;
        align-items: center;
        transition: background .17s;
    }
    .menu-modal.active { display: flex; }
    .menu-modal-content {
        max-width: 94vw;
        max-height: 90vh;
        border-radius: 14px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.20);
        object-fit: contain;
        background: #fff;
    }
    .menu-modal-close {
        position: absolute;
        top: 22px;
        right: 38px;
        color: #fff;
        font-size: 2.7em;
        font-weight: bold;
        cursor: pointer;
        z-index: 10001;
        transition: color .18s;
        text-shadow: 0 2px 18px #000;
        line-height: 0;
    }
    .menu-modal-close:hover { color: #a37c2c; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="index.php" class="logo">A BRILLIANT VISION</a>
        <ul class="nav-links">
            <li><a href="index.php" class="active">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="album.php">Album</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
        </ul>
    </nav>

    <section class="hero">
        <video class="hero-bg-video" autoplay loop muted playsinline>
            <source src="https://assets.mixkit.co/videos/41626/41626-720.mp4" type="video/mp4">
        </video>
        <div class="hero-bg-overlay"></div>
        <div class="hero-title">Creative Vision</div>
        <div class="hero-desc">
            Welcome to A Brilliant Vision Studio, where creativity meets professionalism.<br>
            Explore our world of photography and let us bring your visions to life.
        </div>
        <a href="about.php"><button class="hero-btn">Discover More</button></a>
    </section>

    <section id="gallery" class="gallery-section">
        <div class="gallery-grid">
            <div class="gallery-item"><img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t39.30808-6/508404016_1225118526067672_7498736926226579031_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=f727a1&_nc_eui2=AeEaOm0jbXsapgh_MjQtdy2v7WfiE2pIOkvtZ-ITakg6S7IXSO6cV12LabXBCBIsxUvUc60h3He7urLjjUXXO_8T&_nc_ohc=LxQ2mIQ5WTgQ7kNvwFwcFki&_nc_oc=AdmEuE5iXD4twnKs46SiHaMK8vT52Fb99IYrpTqDIK11GPa1bcXnBMq4Gpvv7dhkfIQ&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&_nc_gid=-ApH1yl5PmPnTKUTf2S-ng&oh=00_AfQ7UzK2-jDo99aL055zONmu5lmI6w1euhtPz7Tci4OPPw&oe=688E066D" alt="Gallery Photo 1"></div>
            <div class="gallery-item"><img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t39.30808-6/508331557_1228284119084446_2520123074506884693_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=f727a1&_nc_eui2=AeGA3yMw6_MwwzshCqXkIEoaaLxKIXaDVL9ovEohdoNUv_iTTBHiisgvUhuzQBj3LOzbg3W_dnQHvu-s51DMBQFM&_nc_ohc=KZQVYYcf2msQ7kNvwH53YxV&_nc_oc=AdnEq1y0prf7HuRUn-FrWisjYJzrra_4uCGGfqAvpxAumuYKeQMw5c5_cWuroy8RvbM&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&_nc_gid=B-YSP-EOcULdkg9phJVEWw&oh=00_AfRHIEAcievyNpOC4w5HwsZjk8krdlDYL8--JZF4Lo949w&oe=688DF826" alt="Gallery Photo 2"></div>
            <div class="gallery-item"><img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t39.30808-6/511198573_1229569948955863_8491669378267833203_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=f727a1&_nc_eui2=AeFSradL09jHw18QY0bNZ8p4GqVxo3eCwTQapXGjd4LBNDBVbqhIagxh1rosZ7xv1rSvQj4aKShguZmZlmlAKb3r&_nc_ohc=ga6_YArRBicQ7kNvwH-4Zme&_nc_oc=Adnsg2fLUUWCK08rNcARtGEjkESsKHhvMqIEkPVDbvRureIt4TVPk-Wpg59cZ3QUelg&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&_nc_gid=qXJqH3cEbhyqi3E9J2Sxqg&oh=00_AfTRcmmy-iIwF-sLdZ8o2NeTwkuu0tyQaqICBqKgoJoTlw&oe=688DF13B" alt="Gallery Photo 3"></div>
            <div class="gallery-item"><img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t39.30808-6/494563260_1239566758168405_7975633462355564155_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=f727a1&_nc_eui2=AeE-005Q-yqQqBpkHUU1UPcUlJhpKkLyvnCUmGkqQvK-cKc64xbgzYIWJNycFR4bPFtHloN4N6J2dMYxrZ7Yc0kD&_nc_ohc=fpafx8dPnIgQ7kNvwFe8whr&_nc_oc=AdlvMe4psQzbpzSq95_DXUkwAclNxJJcNEzxPOj0S18KZz_gT2fwftgqhGUWtt2_nX8&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&_nc_gid=c4G74hOMjkuoqnmwCGTp0g&oh=00_AfRFku4SVAmRNaMKZxBr2Lit5onOdXg54r5CRv1Kucp0Dw&oe=688DFF17" alt="Gallery Photo 4"></div>
            <div class="gallery-item"><img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t39.30808-6/491355861_1233082162150198_8260512281557786100_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=f727a1&_nc_eui2=AeGOeJyQfgaeZ6SpFWKINLj6m6TcUOzVwJSbpNxQ7NXAlJPYWuXy5PaduuAZpSERffxbTE7osXTKtirkvMJqMGut&_nc_ohc=1N9FSK6C3Y4Q7kNvwHsbz2g&_nc_oc=AdnLimUe4r6_FUBPRz0-AfBilVZH8tDvBgfyqWo8aanDRWJGVbJ4KdI0ztgaCj2lSAQ&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&_nc_gid=Lg9Ku6e-37UL8IGz0oMI1A&oh=00_AfRN9ETF7GZyy9prN89AyFLPTsZp1jzrXL_xxxktUdq5xQ&oe=688E140C" alt="Gallery Photo 5"></div>
        </div>
    </section>

    <section id="services" class="services-section">
        <div class="services-title">Our Services</div>
        <div class="services-grid">
            <div class="service-card">
                <div class="service-title">Solo Package <span class="service-price">₱800</span></div>
                <ul class="service-list">
                    <li>30-minutes Studio Photoshoot</li>
                    <li>1 Backdrop</li>
                    <li>50 Enhanced Photos</li>
                    <li>1 A4 Printed Image</li>
                    <li>Online Proof Gallery</li>
                    <li>Free use of Props</li>
                </ul>
            </div>
            <div class="service-card">
                <div class="service-title">Squad Package <span class="service-price">₱2800</span></div>
                <ul class="service-list">
                    <li>2 Hours Studio Photoshoot</li>
                    <li>2 Backdrop</li>
                    <li>2–8 pax</li>
                    <li>150 Enhanced Photos</li>
                    <li>6 Printed Images (4R or wallet size)</li>
                    <li>Online Proof Gallery</li>
                    <li>Free use of Props</li>
                </ul>
            </div>
            <div class="service-card">
                <div class="service-title">Family Package <span class="service-price">₱4800</span></div>
                <ul class="service-list">
                    <li>3 Hours Studio Photoshoot</li>
                    <li>2 Backdrop</li>
                    <li>9–15 pax</li>
                    <li>250 Enhanced Photos</li>
                    <li>10 Printed Images (4R or wallet size)</li>
                    <li>Online Proof Gallery</li>
                    <li>Free use of Props</li>
                </ul>
            </div>
        </div>
        <div style="text-align:center;">
            <a href="booking.php"><button class="book-btn">Book Now</button></a>
        </div>
    </section>
 
    <section class="menu-section" id="cafe-menu" style="padding: 38px 0 18px 0; background: linear-gradient(90deg,#fffdfa 70%,#f7e9d1 100%);">
        <div class="menu-header" style="text-align:center; font-size:2.1em; font-weight:700; letter-spacing:1px; color:#a37c2c; margin-bottom:10px;">
            <span style="display:inline-block; border-bottom:3px solid #a37c2c; padding-bottom:4px;">Studio Café Menu</span>
        </div>
        <div class="menu-desc-container" style="display: flex; justify-content: center;">
            <div class="menu-desc" style="text-align: center; max-width: 540px; font-size:1.15em; color:#6c4c1a; background: #fffdfa; border-radius: 13px; box-shadow: 0 2px 16px 0 rgba(80,50,20,0.08); padding: 18px 28px; margin-bottom: 12px;">
                Enjoy our freshly brewed coffee, refreshing shakes, savory meals, and sweet treats while you create memories in our studio!<br>
                <span style="color: #a37c2c; font-weight: 600; font-size:1.08em;">Hebrews 11:1 Café</span> is open during all studio hours.
            </div>
        </div> 
        </div>
        <div class="cafe-row">
            <img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t1.15752-9/521575099_763750212769136_6510111606376495803_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=9f807c&_nc_eui2=AeFfx-gsscx_tWQNetqptDDq3HtLGb6Vwh3ce0sZvpXCHSSzUhGIYJ2dqsz4rtR7Ob4swfi6g2K-fnH12Ahd4KQm&_nc_ohc=mKnLJXH_fSIQ7kNvwGYCf04&_nc_oc=Adn0WygHCeoG9vc-k3Ptu2XNJ5I_rmTegBU_WuUbHZPONB6nAOYPfzVoEl35YR81Uug&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&oh=03_Q7cD2wFkZ8RrxlJNUJ3G_xQz6HAv9rA82iEwiNGnxapd4bzlGw&oe=68AFAA56"
                 alt="Cafe Menu 1" class="cafe-menu-img" onclick="openCafeMenuModal(this)">
            <img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t1.15752-9/520850571_1714295282530442_5931685023910208246_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=9f807c&_nc_eui2=AeGEirS9l5WtAPQNr_bUlVBDYF0lAkczbi5gXSUCRzNuLmDMvHAeVdlv6SUg_k7UrzTtN0YfoYrvKFvGPzubmSda&_nc_ohc=-ddlKT7NMS4Q7kNvwF8j_0x&_nc_oc=Admfz4NiGW_2bG_yIVCa7qvKQUE_wCHP2_WTp99ggjFCxJozt4O5spbvJ9pDF6-qpyw&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&oh=03_Q7cD2wG35-HWTEYar2H9HEPWWtaspclJV4ySv7xOK4uOpIQIhA&oe=68AFBD27"
                 alt="Cafe Menu 2" class="cafe-menu-img" onclick="openCafeMenuModal(this)">
            <img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t1.15752-9/521288357_1426942548529781_6489673054566727505_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=9f807c&_nc_eui2=AeF0cfXOqgURzN-TrO7nQKoaUhXcwwLu4BVSFdzDAu7gFWOmCG0ZVze9pIynVrQ8ClFVAQBzLXuZ5-9k4CnEIw0z&_nc_ohc=HP60S-UjbnkQ7kNvwH1yl1_&_nc_oc=Adl9uLjyqYsCD1k4WLo0ruCq6ikOCMLdx4HjL2obTRbG_r_oNTxaVU-ruIXwUVGSSdM&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&oh=03_Q7cD2wHqijamXNwaVfBGFXdm9KDvQu2zDPTcT9WRo1gnvKGhJA&oe=68AFB2C7"
                 alt="Cafe Menu 3" class="cafe-menu-img" onclick="openCafeMenuModal(this)">
            <img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t1.15752-9/523200843_1857632734780351_7961708563724380005_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=9f807c&_nc_eui2=AeGJgAh1GcbiuIzWhgp-x_1pm01MyNEkADmbTUzI0SQAOYQe7mdQNdaY2X_cdwhewqbM70h2maSzRtymGdfBdBDN&_nc_ohc=cFxafSvMCcEQ7kNvwFGhES6&_nc_oc=Adk_D5sd1NnD4WfiRrjELty2Yco76K3KLap4LoxXNBzj7OvCX0eZfCfG8DrF-LIf9r8&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&oh=03_Q7cD2wF6MhPn8tQS4KmFRRRY3H19fxKdIUVw0iXpnmAHt7C0lQ&oe=68AFB5DC"
                 alt="Cafe Menu 4" class="cafe-menu-img" onclick="openCafeMenuModal(this)">
        </div>
        <div id="menuModal" class="menu-modal" onclick="closeCafeMenuModal()">
            <span class="menu-modal-close" onclick="closeCafeMenuModal()">&times;</span>
            <img class="menu-modal-content" id="menuModalImg" src="" alt="Cafe Menu Zoom">
        </div>
    </section>

    <section id="about" class="about-section">
        <div class="about-img">
            <img src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t39.30808-6/455964613_1027386372719779_8810808700515699081_n.jpg?stp=dst-jpg_s417x417_tt6&_nc_cat=102&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeF1TP_07Dwjswo1Ut9DKiiAa7U_iDRD9PVrtT-INEP09TjyYz2iHlCBYTOn9xGd8JDbqSqGhEoU6gdxU9-i3w6J&_nc_ohc=7aJne1JXxEIQ7kNvwGvSjUZ&_nc_oc=AdnHyouMtzyBir0qX0uhz026eE4lGGAq6uK6j7ZOqYrJrVHIOo-qOfhe49o0QJ2VnJY&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&_nc_gid=TPGqNwOF1SYJRlRzqDsz9w&oh=00_AfSyObm0HE_WIE0lqhneTqFq2M98wouJeeulY0ufkO7sgg&oe=688DF0A9" alt="Studio Setup">
        </div>
        <div class="about-text">
            <div class="about-title">Our Story</div>
            <div class="about-desc">
                At A Brilliant Vision Studio, we are passionate about transforming moments into timeless memories.<br>
                With a focus on creativity and precision, we strive to provide exceptional photography services that exceed expectations.
            </div>
            <a href="about.php"><button class="about-btn">Learn More</button></a>
        </div>
    </section>

    <section class="testimonial-section-pro" id="testimonials">
        <div class="testimonial-carousel-pro">
            <div class="testimonial-card-pro">
                <div class="testimonial-quote-pro">&ldquo;</div>
                <div class="testimonial-message-pro" id="testimonial-message">
                    Working with A Brilliant Vision Studio was an absolute delight. The attention to detail and creative approach truly set them apart!
                </div>
                <div class="testimonial-quote-pro right">&rdquo;</div>
                <div class="testimonial-photo-wrap-pro">
                    <img id="testimonial-photo" src="https://randomuser.me/api/portraits/women/44.jpg" alt="Client 1" class="testimonial-photo-pro">
                </div>
                <div class="testimonial-stars-pro">
                    <span>&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                </div>
                <div class="testimonial-name-pro" id="testimonial-name">Samantha</div>
                <div class="testimonial-role-pro" id="testimonial-role">Client</div>
                <div class="testimonial-nav-pro">
                    <button class="testimonial-arrow-pro" onclick="changeTestimonial(-1)">&lt;</button>
                    <button class="testimonial-arrow-pro" onclick="changeTestimonial(1)">&gt;</button>
                </div>
                <div class="testimonial-dots-pro" id="testimonial-dots-pro"></div>
            </div>
        </div>
    </section>
    <script>
    const testimonialsPro = [
        {
            message: 'Working with A Brilliant Vision Studio was an absolute delight. The attention to detail and creative approach truly set them apart!',
            name: 'Samantha',
            role: 'Client',
            photo: 'https://randomuser.me/api/portraits/women/44.jpg'
        },
        {
            message: 'The booking process was so easy, and the results were stunning! My family and I are beyond happy with our portraits.',
            name: 'Miguel',
            role: 'Client',
            photo: 'https://randomuser.me/api/portraits/men/34.jpg'
        },
        {
            message: 'Great service, very professional and accommodating. The online gallery was so convenient for sharing photos!',
            name: 'Christine',
            role: 'Client',
            photo: 'https://randomuser.me/api/portraits/women/65.jpg'
        },
        {
            message: 'Super friendly team and amazing studio setup. I loved the props and how easy it was to book online!',
            name: 'John',
            role: 'Client',
            photo: 'https://randomuser.me/api/portraits/men/68.jpg'
        },
        {
            message: 'My graduation shoot was perfect. Creative direction and fast delivery. Will recommend to friends!',
            name: 'Bella',
            role: 'Client',
            photo: 'https://randomuser.me/api/portraits/women/25.jpg'
        }
    ];
    let tIndex = 0;
    const msg = document.getElementById('testimonial-message');
    const nameEl = document.getElementById('testimonial-name');
    const roleEl = document.getElementById('testimonial-role');
    const photoEl = document.getElementById('testimonial-photo');
    const dotsWrap = document.getElementById('testimonial-dots-pro');
    function renderDots() {
        dotsWrap.innerHTML = '';
        for(let i=0;i<testimonialsPro.length;i++){
            let dot = document.createElement('div');
            dot.className = 'testimonial-dot-pro' + (i===tIndex?' active':'');
            dot.onclick = ()=>{tIndex=i;showTestimonial();}
            dotsWrap.appendChild(dot);
        }
    }
    function showTestimonial() {
        msg.innerHTML = testimonialsPro[tIndex].message;
        nameEl.innerHTML = testimonialsPro[tIndex].name;
        roleEl.innerHTML = testimonialsPro[tIndex].role;
        photoEl.src = testimonialsPro[tIndex].photo;
        renderDots();
    }
    function changeTestimonial(d){
        tIndex+=d;
        if(tIndex<0) tIndex=testimonialsPro.length-1;
        if(tIndex>=testimonialsPro.length) tIndex=0;
        showTestimonial();
    }
    showTestimonial();

    function openCafeMenuModal(img) {
        var modal = document.getElementById('menuModal');
        var modalImg = document.getElementById('menuModalImg');
        modalImg.src = img.src;
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closeCafeMenuModal() {
        var modal = document.getElementById('menuModal');
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
    window.addEventListener('keydown', function(e){
        if(e.key==='Escape'){ closeCafeMenuModal(); }
    });
    </script>

    <div class="footer">
        &copy; <?=date('Y')?> A Brilliant Vision Studio. All Rights Reserved.
    </div>
</body>
</html>
