<?php
session_start();
$albumTab = $_GET['album_tab'] ?? 'solo';

$album_dirs = [
    'solo' => "album_uploads/solo/",
    'squad' => "album_uploads/squad/",
    'family' => "album_uploads/family/"
];
$tab_titles = [
    'solo' => 'Solo Album',
    'squad' => 'Squad Album',
    'family' => 'Family Album'
];

// Ensure the directory exists
$curr_album_dir = $album_dirs[$albumTab] ?? $album_dirs['solo'];
if (!is_dir($curr_album_dir)) mkdir($curr_album_dir, 0777, true);

// List all album-uploaded photos for the selected tab
$photos = array_filter(scandir($curr_album_dir), function($f) use ($curr_album_dir) {
    return !is_dir($curr_album_dir . $f) && preg_match('/\.(jpe?g|png)$/i', $f);
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Album | A Brilliant Vision</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
    :root {
        --main-bg: #fcfaf4;
        --accent: #232323;
        --headline: #232323;
        --highlight: #a37c2c;
        --soft-grey: #f4f3ed;
    }
    html, body {
        margin: 0; padding: 0;  
        background: var(--main-bg);
        color: var(--accent);
        font-family: 'Montserrat', Arial, sans-serif;
    }
    body { padding-top: 86px; }
    .navbar {
        position: fixed;
        top: 0; left: 0;
        width: 100vw;
        z-index: 100;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1.5em 5vw 1em 4vw;
        background: var(--main-bg);
        box-shadow: 0 2px 14px 0 rgba(60,60,80,0.06);
    }
    .logo {
        font-size: 1.3em;
        color: var(--headline);
        font-weight: 600;
        letter-spacing: 2px;
        text-decoration: none;
    }
    .nav-links {
        display: flex;
        gap: 2.2em;
        list-style: none;
        margin: 0; padding: 0;
    }
    .nav-links a {
        color: var(--accent);
        font-size: 1em;
        font-weight: 400;
        text-decoration: none;
        letter-spacing: .4px;
        padding: 3px 1px;
        position: relative;
        transition: color 0.16s;
    }
    .nav-links a::after {
        content: '';
        display: block;
        width: 0;
        height: 2px;
        background: var(--highlight);
        transition: width 0.21s;
        position: absolute;
        left: 0;
        bottom: 0;
    }
    .nav-links a.active,
    .nav-links a:hover {
        color: #a37c2c;
    }
    .nav-links a.active::after,
    .nav-links a:hover::after {
        width: 100%;
    }
    .album-tabs {
        text-align: center;
        margin: 30px 0 24px 0;
        display: flex;
        justify-content: center;
        gap: 18px;
    }
    .album-tab-btn {
        padding: 9px 36px;
        border: 1.6px solid #a37c2c;
        background: #fff;
        color: #a37c2c;
        font-size: 1.02em;
        font-weight: 600;
        border-radius: 16px;
        cursor: pointer;
        outline: none;
        transition: background 0.18s, color 0.18s;
    }
    .album-tab-btn.active,
    .album-tab-btn:hover {
        background: #a37c2c;
        color: #fff;
    }
    .gallery-header {
        text-align: center;
        margin: 18px 0 12px 0;
        font-size: 2.3em;
        font-weight: 600;
        letter-spacing: 1px;
        color: var(--headline);
    }
    .gallery-wrap {
        padding-bottom: 60px;
        max-width: 1240px;
        margin: 0 auto;
    }
    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 38px 38px;
        padding: 0 4vw;
        margin: 0 auto;
    }
    .gallery-photo {
        aspect-ratio: 3 / 4;
        background: #f4f3ed;
        box-shadow: 0 2px 8px rgba(90,90,110,0.10);
        overflow: hidden;
        border-radius: 0;
        cursor: pointer;
        display: flex;
        align-items: stretch;
        transition: box-shadow 0.24s;
    }
    .gallery-photo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 0;
        transition: transform 0.36s cubic-bezier(.45,1.45,.38,.97);
        will-change: transform;
        display: block;
    }
    .gallery-photo:hover img {
        transform: scale(1.10);
        z-index: 2;
    }
    @media (max-width:1050px) { .gallery-grid { gap: 18px 13px; } }
    @media (max-width: 880px) { .gallery-grid { grid-template-columns: repeat(2,1fr);} }
    @media (max-width: 600px) { .gallery-grid { grid-template-columns: 1fr;} .gallery-wrap { padding-top: 75px;} }
    .footer {
        text-align: center;
        color: #a7a7a7;
        font-size: .98em;
        margin: 60px 0 15px 0;
    }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <a href="index.php" class="logo">A BRILLIANT VISION</a>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="album.php" class="active">Album</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
        </ul>
    </nav>
    <!-- Album Tabs -->
    <div class="album-tabs">
        <a href="album.php?album_tab=solo"><button class="album-tab-btn<?= ($albumTab === 'solo') ? ' active' : '' ?>">Solo</button></a>
        <a href="album.php?album_tab=squad"><button class="album-tab-btn<?= ($albumTab === 'squad') ? ' active' : '' ?>">Squad</button></a>
        <a href="album.php?album_tab=family"><button class="album-tab-btn<?= ($albumTab === 'family') ? ' active' : '' ?>">Family</button></a>
    </div>
    <!-- Gallery Header -->
    <div class="gallery-header"><?= htmlspecialchars($tab_titles[$albumTab] ?? 'Solo Album') ?></div>
    <!-- Gallery -->
    <div class="gallery-wrap">
        <div class="gallery-grid">
            <?php foreach($photos as $file): ?>
                <div class="gallery-photo">
                    <img src="<?= $curr_album_dir . $file ?>" alt="<?= htmlspecialchars($tab_titles[$albumTab] ?? 'Album Photo') ?>">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="footer">
        &copy; <?=date('Y')?> A Brilliant Vision Studio. All Rights Reserved.
    </div>
</body>
</html>
