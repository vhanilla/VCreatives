<?php
session_start();
$error = '';
if (isset($_POST['username']) && isset($_POST['password'])) {
    $users = [
        "admin" => ["password" => "admin123", "role" => "admin"],
        "client" => ["password" => "client123", "role" => "client"]
    ];
    $username = strtolower(trim($_POST['username']));
    $password = trim($_POST['password']);
    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $_SESSION['user'] = $username;
        $_SESSION['role'] = $users[$username]['role'];
        if ($_SESSION['role'] === "admin") {
            header("Location: admin.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | A Brilliant Vision</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
    <style>
        :root {
            --main-bg: #fcfaf4;
            --accent: #232323;
            --highlight: #a37c2c;
        }
        body {
            margin: 0; padding: 0;
            font-family: 'Montserrat', Arial, sans-serif;
            background: var(--main-bg);
        }
        .split-login-wrap {
            min-height: 100vh;
            display: flex;
            flex-direction: row;
        }
        .login-photo-side {
            flex: 1.2;
            position: relative;
            background: #222;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 0;
            overflow: hidden;
        }
        .login-photo-bg {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            object-fit: cover;
            z-index: 1;
            filter: brightness(0.88) blur(0px);
            transition: filter 0.2s;
        }
        .login-photo-overlay {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(20,17,30, 0.23);
            z-index: 2;
        }
        .login-photo-content {
            position: relative;
            z-index: 3;
            color: #fff;
            text-align: left;
            max-width: 380px;
            padding: 0 32px;
            font-family: 'Playfair Display', serif;
        }
        .login-photo-content h1 {
            font-size: 2.4em;
            margin-bottom: 14px;
            font-weight: 600;
            letter-spacing: 2.5px;
            color: #ffe8bc;
            text-shadow: 0 5px 22px rgba(0,0,0,0.17);
        }
        .login-photo-content .credit {
            font-size: 1.11em;
            margin-bottom: 19px;
            color: #ffe6c6;
        }
        .login-photo-content p {
            font-size: 1.1em;
            color: #eee;
            font-family: 'Montserrat', Arial, sans-serif;
            font-weight: 400;
            text-shadow: 0 3px 15px rgba(0,0,0,0.11);
        }
        /* Login FORM SIDE */
        .login-form-side {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 0;
            background: #fff;
        }
        .login-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 6px 32px rgba(60,55,70,0.07);
            padding: 44px 34px 36px 34px;
            max-width: 370px;
            width: 100%;
            margin: 46px 22px;
        }
        .login-title {
            font-family: 'Playfair Display', serif;
            font-size: 2.1em;
            color: #232323;
            font-weight: 600;
            text-align: center;
            margin-bottom: 11px;
        }
        .login-desc {
            color: #777;
            font-size: 1.05em;
            margin-bottom: 24px;
            text-align: center;
        }
        .login-form label {
            font-size: 1em;
            font-weight: 500;
            color: #232323;
            margin-bottom: 5px;
            display: block;
        }
        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: 100%;
            padding: 13px 12px;
            font-size: 1em;
            margin-bottom: 19px;
            border: 1.2px solid #e1e1e1;
            border-radius: 5px;
            background: #fcfaf4;
            outline: none;
            transition: border 0.16s;
        }
        .login-form input[type="text"]:focus,
        .login-form input[type="password"]:focus {
            border: 1.5px solid #a37c2c;
            background: #fffbe8;
        }
        .login-btn {
            width: 100%;
            background: var(--accent);
            color: #fff;
            border: none;
            border-radius: 22px;
            padding: 12px 0;
            font-size: 1.09em;
            font-weight: 500;
            letter-spacing: 1px;
            cursor: pointer;
            margin-bottom: 11px;
            transition: background .17s;
        }
        .login-btn:hover {
            background: #a37c2c;
        }
        .google-btn {
            width: 100%;
            background: #fff;
            color: #232323;
            border: 1.3px solid #bbb;
            border-radius: 22px;
            padding: 10px 0;
            font-weight: 500;
            font-size: 1em;
            margin-top: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 2px 8px rgba(30,30,30,0.05);
            text-decoration: none;
            transition: background 0.15s, color 0.15s, border 0.15s;
        }
        .google-btn img {
            width: 22px; height: 22px; margin-right: 8px;
        }
        .google-btn:hover {
            background: #f4f3ed;
            color: #a37c2c;
            border: 1.3px solid #a37c2c;
        }
        .demo-info {
            text-align: center;
            margin-top: 17px;
            color: #999;
            font-size: .97em;
        }
        .error-msg {
            background: #ffe6e6; color: #b43434;
            padding: 9px 12px; border-radius: 5px;
            text-align: center; margin-bottom: 15px;
            font-size: 1.03em;
        }
        .login-links {
            text-align: center; margin-top: 18px; color: #888;
            font-size: .97em;
        }
        .login-links a { color: #a37c2c; text-decoration: none; }
        .login-links a:hover { text-decoration: underline; }

        @media (max-width: 950px) {
            .split-login-wrap { flex-direction: column; }
            .login-photo-side, .login-form-side { width: 100%; min-height: 260px; }
            .login-photo-content { padding: 44px 18px 30px 18px; max-width: 98vw; }
            .login-card { margin: 34px auto 34px auto; }
        }
        @media (max-width: 600px) {
            .login-card { padding: 22px 3vw; }
            .login-title { font-size: 1.37em;}
        }
    </style>
</head>
<body>
<div class="split-login-wrap">
    <!-- Left: PHOTO BACKGROUND & OVERLAY -->
    <div class="login-photo-side">
        <img class="login-photo-bg" src="https://scontent.fmnl22-1.fna.fbcdn.net/v/t39.30808-6/455964613_1027386372719779_8810808700515699081_n.jpg?_nc_cat=102&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeF1TP_07Dwjswo1Ut9DKiiAa7U_iDRD9PVrtT-INEP09TjyYz2iHlCBYTOn9xGd8JDbqSqGhEoU6gdxU9-i3w6J&_nc_ohc=ly824kXCsX0Q7kNvwEPk13k&_nc_oc=AdmKd4HuM9h4ICJtZXlbnZWoeCGCVseNuCUM-y8GXPOesnCQWnnyETacGdxUhT6V4i0&_nc_zt=23&_nc_ht=scontent.fmnl22-1.fna&_nc_gid=Z1fX38yZbSCl-ua-Rb76Jg&oh=00_AfRZcXr1Lg8Av8m6u1TmynFn7ylCbmt0I3P75rSgfhAgYg&oe=688BBE29" alt="Login Visual Background">
        <div class="login-photo-overlay"></div>
        <div class="login-photo-content">
            <h1></h1>
            
        </div>
    </div>
    <!-- Right: LOGIN FORM -->
    <div class="login-form-side">
        <div class="login-card">
            <div class="login-title">Sign In</div>
            <div class="login-desc">
                
            </div>
            <?php if($error): ?><div class="error-msg"><?= $error ?></div><?php endif; ?>
            <form method="post" class="login-form" autocomplete="off">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" placeholder="Enter your username" required autofocus>
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Enter your password" required>
                <button class="login-btn" type="submit">Sign In</button>
            </form>
            <a href="google-login.php" class="google-btn">
                <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/google/google-original.svg" alt="Google icon">
                Sign In with Google
            </a>

            <div class="login-links">
                <a href="index.php">← View as Guest</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
