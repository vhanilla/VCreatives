<?php
session_start();

$bookingSuccess = false;
$errors = [];
$bookingFile = "bookings.json";
if (!file_exists($bookingFile)) file_put_contents($bookingFile, "[]");

// Get existing bookings
$bookings = json_decode(file_get_contents($bookingFile), true);

// Used to disable already booked dates
$booked_dates = array_column($bookings, 'date');

// Get blocked dates by admin
$blocked_dates = [];
$calendarFile = "calendar_blocked.json";
if (file_exists($calendarFile)) {
    $blocked_dates = json_decode(file_get_contents($calendarFile), true);
}

// Combine for client-side disabling
$disabled_dates = array_unique(array_merge($booked_dates, $blocked_dates));

// Handle step (choose package or show form)
$chosen_package = $_GET['package'] ?? $_POST['package'] ?? '';

// Handle booking submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_booking'])) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $package = $_POST['package'] ?? '';
    $date = $_POST['date'] ?? '';
    $notes = trim($_POST['notes'] ?? '');

    // Validate
    if ($name == '' || $email == '' || $phone == '' || $package == '' || $date == '') {
        $errors[] = "Please fill in all required fields.";
    }
    // Check if date already booked or blocked
    if (in_array($date, $disabled_dates)) {
        $errors[] = "Sorry, this date is already booked or unavailable. Please choose another date.";
    }

    // Save booking if valid
    if (!$errors) {
        $bookings[] = [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'package' => $package,
            'date' => $date,
            'notes' => $notes,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        file_put_contents($bookingFile, json_encode($bookings, JSON_PRETTY_PRINT));
        $bookingSuccess = true;
        $chosen_package = '';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book a Session | A Brilliant Vision</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=2">
    <style>
        .packages-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 2.6em;
            margin: 70px auto 50px auto;
            max-width: 1150px;
            width: 100%;
            box-sizing: border-box;
        }
        .package-card {
            background: #fff;
            border-radius: 13px;
            box-shadow: 0 3px 24px #0002;
            overflow: hidden;
            width: 320px;
            min-height: 420px;
            display: flex;
            flex-direction: column;
            align-items: stretch;
            cursor: pointer;
            transition: box-shadow .18s, transform .16s;
            outline: none;
        }
        .package-card:hover,
        .package-card:focus {
            box-shadow: 0 0 0 3px #a37c2c55, 0 8px 28px #0002;
            transform: translateY(-2px) scale(1.02);
        }
        .package-card img {
            width: 100%; height: 180px; object-fit: cover;
            background: #f4f3ed;
        }
        .package-content {
            padding: 18px 24px 18px 24px;
            flex: 1 1 auto;
            display: flex; flex-direction: column;
        }
        .package-title {
            font-size: 1.21em; font-weight: 600;
            color: #232323; margin-bottom: 6px;
        }
        .package-price {
            color: #a37c2c; font-weight: 600;
            font-size: 1.03em; margin-bottom: 9px;
        }
        .package-features {
            margin: 0 0 12px 0; padding: 0 0 0 19px;
            font-size: 1em; color: #383838;
        }
        .booking-section {
            background: var(--soft-grey, #f8f8f5);
            max-width: 480px;
            margin: 70px auto 50px auto;
            border-radius: 20px;
            box-shadow: 0 6px 40px #cec8df15;
            padding: 35px 32px 25px 32px;
        }
        .booking-title {
            text-align: center;
            font-size: 2.1em;
            font-weight: 600;
            margin-bottom: 22px;
            color: var(--headline, #232323);
            letter-spacing: .7px;
        }
        .booking-form label {
            font-size: 1em;
            color: var(--accent, #232323);
            margin-bottom: 6px;
            display: block;
            font-weight: 500;
        }
        .booking-form input, .booking-form select, .booking-form textarea {
            width: 100%;
            padding: 11px 12px;
            font-size: 1em;
            margin-bottom: 18px;
            border: 1.3px solid var(--border, #f0ede5);
            border-radius: 5px;
            background: #fcfaf4;
            font-family: inherit;
            resize: none;
            box-sizing: border-box;
        }
        .booking-btn {
            width: 100%;
            background: var(--accent, #232323);
            color: #fff;
            border: none;
            padding: 14px 0;
            font-size: 1.08em;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 6px;
            transition: background .18s;
            box-shadow: 0 2px 10px #e6e6e6aa;
        }
        .booking-btn:hover {
            background: var(--highlight, #a37c2c);
            color: #fff;
        }
        .success-msg {
            background: #e6ffe6;
            color: #186a18;
            padding: 10px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 1.08em;
            text-align: center;
        }
        .error-msg {
            background: #ffe6e6;
            color: #b43434;
            padding: 8px 12px;
            border-radius: 7px;
            margin-bottom: 14px;
            text-align: center;
            font-size: 1em;
        }
        @media (max-width: 1150px) {
            .packages-list {
                max-width: 98vw;
                gap: 1.4em;
            }
        }
        @media (max-width: 1050px) {
            .package-card {
                width: 290px;
                min-height: 380px;
            }
        }
        @media (max-width: 950px) {
            .packages-list {
                gap: 1em;
            }
            .package-card {
                width: 260px;
                min-height: 350px;
            }
        }
        @media (max-width: 820px) {
            .package-card {
                width: 98vw;
                max-width: 400px;
                min-width: 0;
                margin: 0 auto;
            }
            .packages-list {
                gap: 1em;
            }
        }
        @media (max-width: 600px) {
            .packages-list, .booking-section {
                max-width: 99vw;
                padding: 0 1vw;
            }
            .package-card {
                width: 99vw;
                max-width: 99vw;
                margin: 0 auto;
                min-height: unset;
            }
        }
    </style>
    <script>
    var bookedDates = <?= json_encode($disabled_dates) ?>;
    window.addEventListener('DOMContentLoaded', function() {
        var dateInput = document.getElementById('date');
        if (!dateInput) return;
        dateInput.addEventListener('input', function() {
            if (bookedDates.includes(this.value)) {
                alert("Sorry, this date is already booked or unavailable. Please choose another date.");
                this.value = '';
            }
        });
        dateInput.setAttribute('min', new Date().toISOString().slice(0,10));
        dateInput.addEventListener('keydown', function(e){
            setTimeout(()=>{
                if (bookedDates.includes(this.value)) {
                    alert("Sorry, this date is already booked or unavailable. Please choose another date.");
                    this.value = '';
                }
            }, 100);
        });
    });
    function goToBooking(el) {
        var pkg = el.getAttribute('data-package');
        if(pkg) window.location.href = '?package=' + encodeURIComponent(pkg);
    }
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.package-card').forEach(card => {
            card.addEventListener('focus', () => card.style.boxShadow = "0 0 0 3px #a37c2c55, 0 3px 24px #0002");
            card.addEventListener('blur', () => card.style.boxShadow = "0 3px 24px #0002");
        });
    });
    </script>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <a href="index.php" class="logo">A BRILLIANT VISION</a>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="album.php">Album</a></li>
            <li><a href="booking.php" class="active">Booking</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </nav>

    <!-- Packages List (side by side, no horizontal scroll) -->
    <?php if (!$chosen_package && !$bookingSuccess): ?>
    <div style="text-align:center; margin-top:48px;">
        <h2 style="font-size:2.2em; font-weight:600; letter-spacing:1.5px; color:#232323;">Choose a Photography Package</h2>
    </div>
    <div class="packages-list">
        <!-- Solo Package -->
        <div class="package-card" tabindex="0" data-package="Solo Package" onclick="goToBooking(this)" onkeypress="if(event.key==='Enter'){goToBooking(this);}">
            <img src="https://images.pexels.com/photos/1707828/pexels-photo-1707828.jpeg?auto=compress&w=600" alt="Solo Package">
            <div class="package-content">
                <div class="package-title">Solo Package</div>
                <div class="package-price">₱800</div>
                <ul class="package-features">
                    <li>30-minutes Studio Photoshoot</li>
                    <li>1 Backdrop</li>
                    <li>50 Enhanced Photos</li>
                    <li>1 A4 Printed Image</li>
                    <li>Online Proof Gallery</li>
                </ul>
            </div>
        </div>
        <!-- Squad Package -->
        <div class="package-card" tabindex="0" data-package="Squad Package" onclick="goToBooking(this)" onkeypress="if(event.key==='Enter'){goToBooking(this);}">
            <img src="https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&w=600" alt="Squad Package">
            <div class="package-content">
                <div class="package-title">Squad Package</div>
                <div class="package-price">₱2800</div>
                <ul class="package-features">
                    <li>2 Hours Studio Photoshoot</li>
                    <li>2 Backdrop</li>
                    <li>2–8 pax</li>
                    <li>150 Enhanced Photos</li>
                    <li>6 Printed Images (4R or wallet size)</li>
                </ul>
            </div>
        </div>
        <!-- Family Package -->
        <div class="package-card" tabindex="0" data-package="Family Package" onclick="goToBooking(this)" onkeypress="if(event.key==='Enter'){goToBooking(this);}">
            <img src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&w=600" alt="Family Package">
            <div class="package-content">
                <div class="package-title">Family Package</div>
                <div class="package-price">₱4800</div>
                <ul class="package-features">
                    <li>3 Hours Studio Photoshoot</li>
                    <li>2 Backdrop</li>
                    <li>9–15 pax</li>
                    <li>250 Enhanced Photos</li>
                    <li>10 Printed Images (4R or wallet size)</li>
                </ul>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Booking form (shows after package is chosen or after failed validation) -->
    <?php if ($chosen_package && !$bookingSuccess): ?>
    <div class="booking-section">
        <div class="booking-title">Book: <?=htmlspecialchars($chosen_package)?></div>
        <?php foreach($errors as $err): ?>
            <div class="error-msg"><?=htmlspecialchars($err)?></div>
        <?php endforeach; ?>
        <form method="post" class="booking-form" autocomplete="off">
            <input type="hidden" name="package" value="<?=htmlspecialchars($chosen_package)?>">
            <label for="date">Preferred Date</label>
            <input type="date" name="date" id="date" min="<?=date('Y-m-d')?>" required value="<?=htmlspecialchars($_POST['date'] ?? '')?>">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" required value="<?=htmlspecialchars($_POST['name'] ?? '')?>">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" required value="<?=htmlspecialchars($_POST['email'] ?? '')?>">
            <label for="phone">Phone</label>
            <input type="text" name="phone" id="phone" required value="<?=htmlspecialchars($_POST['phone'] ?? '')?>">
            <label for="notes">Special Requests / Notes</label>
            <textarea name="notes" id="notes" rows="3" placeholder="Let us know anything special..."><?=htmlspecialchars($_POST['notes'] ?? '')?></textarea>
            <button type="submit" class="booking-btn" name="do_booking">Book Now</button>
        </form>
    </div>
    <?php elseif ($bookingSuccess): ?>
        <div class="booking-section">
            <div class="success-msg">Thank you for booking! We'll contact you soon for confirmation.</div>
            <div style="text-align:center;margin-top:10px;">
                <a href="booking.php" style="color:#a37c2c;text-decoration:underline;">← Book another session</a>
            </div>
        </div>
    <?php endif; ?>

    <div class="footer">
        &copy; <?=date('Y')?> A Brilliant Vision Studio. All Rights Reserved.
    </div>
</body>
</html>
