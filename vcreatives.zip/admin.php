<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== "admin") {
    header("Location: login.php");
    exit();
}
$tab = $_GET['tab'] ?? 'album';
$albumTab = $_GET['album_tab'] ?? 'solo';

// --- ALBUM LOGIC ---
$album_dirs = [
    'solo' => "album_uploads/solo/",
    'squad' => "album_uploads/squad/",
    'family' => "album_uploads/family/"
];

// Ensure directories exist
foreach ($album_dirs as $dir) {
    if (!is_dir($dir)) mkdir($dir, 0777, true);
}

$msg = '';
if ($tab === 'album' && isset($_POST['upload'])) {
    $albumTab = $_POST['album_tab'] ?? 'solo';
    $upload_dir = $album_dirs[$albumTab] ?? $album_dirs['solo'];
    if (!empty($_FILES['photo']['name'])) {
        $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        $filename = uniqid("photo_", true) . '.' . $ext;
        $dest = $upload_dir . $filename;
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $dest)) {
            $msg = "Photo uploaded to " . ucfirst($albumTab) . " Album!";
        } else {
            $msg = "Failed to upload photo.";
        }
    }
}
if ($tab === 'album' && isset($_GET['del']) && !empty($_GET['del'])) {
    $albumTab = $_GET['album_tab'] ?? 'solo';
    $upload_dir = $album_dirs[$albumTab] ?? $album_dirs['solo'];
    $file = basename($_GET['del']);
    if (file_exists($upload_dir . $file)) {
        unlink($upload_dir . $file);
        $msg = "Photo deleted from " . ucfirst($albumTab) . " Album.";
    }
}
$curr_album_dir = $album_dirs[$albumTab] ?? $album_dirs['solo'];
$photos = array_filter(scandir($curr_album_dir), function($f) use ($curr_album_dir) {
    return !is_dir($curr_album_dir . $f) && preg_match('/\.(jpe?g|png)$/i', $f);
});

// --- BOOKINGS LOGIC ---
$bookingFile = "bookings.json";
$bookings = file_exists($bookingFile) ? json_decode(file_get_contents($bookingFile), true) : [];

// Handle booking deletion
if ($tab === 'bookings' && isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    $remove_idx = intval($_GET['remove']);
    $bookings = array_values($bookings);
    if (isset($bookings[$remove_idx])) {
        array_splice($bookings, $remove_idx, 1);
        file_put_contents($bookingFile, json_encode($bookings, JSON_PRETTY_PRINT));
        $msg = "Booking removed.";
    }
}

// --- Handle booking confirmation & email notification ---
if ($tab === 'bookings' && isset($_GET['confirm']) && is_numeric($_GET['confirm'])) {
    $confirm_idx = intval($_GET['confirm']);
    $bookings = array_values($bookings);
    if (isset($bookings[$confirm_idx])) {
        $bookings[$confirm_idx]['confirmed'] = true;
        file_put_contents($bookingFile, json_encode($bookings, JSON_PRETTY_PRINT));
        // Send notification email
        $to = $bookings[$confirm_idx]['email'];
        $subject = "Your Booking at A Brilliant Vision is Confirmed!";
        $message = "Hello " . htmlspecialchars($bookings[$confirm_idx]['name']) . ",\n\n".
            "Your booking for " . htmlspecialchars($bookings[$confirm_idx]['package']) . " on " . htmlspecialchars($bookings[$confirm_idx]['date']) . " has been confirmed!\n\n".
            "Thank you for choosing A Brilliant Vision Studio.\n\nBest regards,\nA Brilliant Vision Team";
        $headers = "From: vcreatives@gmail.com\r\n";
        @mail($to, $subject, $message, $headers);
        $msg = "Booking confirmed and client notified by email.";
    }
}

// --- CALENDAR LOGIC ---
$calendarFile = "calendar_blocked.json";
$blocked_dates = file_exists($calendarFile) ? json_decode(file_get_contents($calendarFile), true) : [];

if ($tab === 'calendar' && isset($_POST['block_date'])) {
    $date = $_POST['block_date'];
    if ($date && !in_array($date, $blocked_dates)) {
        $blocked_dates[] = $date;
        file_put_contents($calendarFile, json_encode($blocked_dates, JSON_PRETTY_PRINT));
        $msg = "Date blocked!";
    }
}
if ($tab === 'calendar' && isset($_GET['unblock']) && in_array($_GET['unblock'], $blocked_dates)) {
    $blocked_dates = array_values(array_diff($blocked_dates, [$_GET['unblock']]));
    file_put_contents($calendarFile, json_encode($blocked_dates, JSON_PRETTY_PRINT));
    $msg = "Date unblocked!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel | A Brilliant Vision</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --main-bg: #fcfaf4;
            --accent: #232323;
            --headline: #232323;
            --highlight: #a37c2c;
            --sidebar-bg: #fff;
            --border: #f0ede5;
        }
        html, body {
            margin: 0; padding: 0;
            font-family: 'Montserrat', Arial, sans-serif;
            background: var(--main-bg);
            min-height: 100vh;
            width: 100vw;
            overflow-x: hidden;
        }
        body { min-height: 100vh; display: flex; }
        .sidebar {
            position: fixed;
            top: 0; left: 0;
            height: 100vh;
            width: 220px;
            background: var(--sidebar-bg);
            border-right: 1.7px solid var(--border);
            box-shadow: 2px 0 13px 0 rgba(60,60,80,0.07);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            padding: 44px 0 0 0;
            z-index: 999;
        }
        .sidebar-logo {
            font-size: 1.13em;
            color: var(--headline);
            font-weight: 600;
            letter-spacing: 2px;
            margin-left: 32px;
            margin-bottom: 34px;
            text-decoration: none;
        }
        .sidebar-links { width: 100%; }
        .sidebar-links a {
            display: block;
            color: var(--accent);
            font-size: 1.05em;
            font-weight: 500;
            text-decoration: none;
            padding: 13px 28px;
            width: 100%;
            transition: background 0.16s, color 0.13s;
            border-left: 4px solid transparent;
            background: transparent;
        }
        .sidebar-links a.active,
        .sidebar-links a:hover {
            background: #f4f3ed;
            color: #a37c2c;
            border-left: 4px solid #a37c2c;
        }
        .sidebar-logout {
            margin-top: auto;
            width: 100%;
            padding-bottom: 30px;
        }
        .sidebar-logout button {
            width: 100%;
            background: #232323;
            color: #fff;
            border: none;
            border-radius: 0;
            padding: 12px 0;
            font-size: 1em;
            font-family: inherit;
            cursor: pointer;
            font-weight: 500;
            letter-spacing: 1px;
            transition: background 0.15s;
        }
        .sidebar-logout button:hover { background: #a37c2c; }
        .admin-content {
            margin-left: 220px;
            width: calc(100% - 220px);
            min-height: 100vh;
            background: var(--main-bg);
            padding-bottom: 32px;
        }
        .admin-header {
            max-width: 980px;
            margin: 56px auto 30px auto;
            padding-top: 30px;
            text-align: center;
        }
        .admin-header h2 {
            font-size:2em; margin-bottom: 10px; font-weight: 600;
            color: #232323;
        }
        .msg {
            text-align:center; color:#a37c2c; margin:10px 0;
            font-size: 1.1em; font-weight: 500;
        }
        .album-tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 25px;
            gap: 14px;
        }
        .album-tab-btn {
            padding: 10px 28px;
            background: #fff;
            color: #232323;
            border: 1.5px solid #a37c2c;
            border-radius: 18px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: background .15s, color .15s;
        }
        .album-tab-btn.active,
        .album-tab-btn:hover {
            background: #a37c2c;
            color: #fff;
        }
        .upload-form {
            display:flex; gap:10px;
            justify-content:center; align-items:center; margin-bottom:28px;
        }
        .upload-form select {
            padding: 8px 10px;
            font-size: 1em;
            border-radius: 7px;
            border: 1px solid #a37c2c;
        }
        .upload-form input[type="file"] {font-size:1em;}
        .upload-form button {
            background: #232323; color:#fff; border:none; border-radius:18px;
            padding:8px 22px; font-size:1em; cursor:pointer; font-family: inherit; font-weight: 500;
            transition: background .15s;
        }
        .upload-form button:hover { background: #a37c2c; }
        .album-photos-admin {
            display: grid;
            grid-template-columns: repeat(auto-fit,minmax(160px,1fr));
            gap: 34px 38px; justify-content: center;
            max-width: 950px; margin: 0 auto 50px auto;
            padding: 0 3vw;
        }
        .admin-photo-item {
            background: #fff;
            border:1.5px solid #eee;
            border-radius: 8px;
            box-shadow: 0 2px 12px #ccc3;
            display:flex; flex-direction:column; align-items:center;
            padding:14px 8px 10px 8px;
        }
        .admin-photo-item img {
            width: 100%; max-width: 135px; height:180px;
            object-fit:cover; display:block; border-radius:3px; margin-bottom:11px;
            box-shadow: 0 1px 7px #c8c8c844;
        }
        .delete-link {
            color:#c24; text-decoration:none; font-size:.97em; margin-top: 3px; font-weight: 500;
            letter-spacing: .2px; transition: color .13s;
        }
        .delete-link:hover { text-decoration:underline; color: #a37c2c;}
        .booking-table {
            border-collapse: collapse;
            width: 98%;
            margin: 18px auto 0 auto;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 14px 0 rgba(60,60,80,0.06);
        }
        .booking-table th, .booking-table td {
            padding: 12px 10px;
            border-bottom: 1px solid #f0ede5;
            font-size: 1em;
            text-align: left;
        }
        .booking-table th {
            background: #f4f3ed;
            color: #a37c2c;
            font-weight: 600;
        }
        .booking-table tr:last-child td { border-bottom: none;}
        .sidebar::after {
            content: "";
            position: absolute;
            right: -1.7px;
            top: 0;
            width: 1.7px;
            height: 100%;
            background: var(--border);
            z-index: 1;
            display: block;
        }
        .blocked-list li { margin-bottom:8px; }
        @media (max-width: 1050px) {
            .admin-header,
            .album-photos-admin,
            .booking-table {
                max-width: 98vw;
            }
        }
        @media (max-width: 800px) {
            .sidebar {
                width: 68px;
                align-items: center;
                padding-left: 0;
                min-width: 68px;
            }
            .sidebar-logo {
                font-size: 0.85em;
                margin: 0 0 18px 0;
                text-align:center;
                margin-left:0;
            }
            .sidebar-links a {
                font-size:0.92em;
                padding:13px 9px;
                text-align:center;
                border-left:none;
                border-bottom: 3px solid transparent;
            }
            .sidebar-links a.active, .sidebar-links a:hover {
                border-left:none;
                border-bottom: 3px solid #a37c2c;
            }
            .sidebar-logout {
                padding-bottom:10px;
            }
            .admin-content {
                margin-left: 68px;
                width: calc(100% - 68px);
            }
        }
        @media (max-width: 600px) {
            body {
                flex-direction: column;
            }
            .sidebar {
                position: static;
                height: auto;
                width: 100vw;
                min-width: unset;
                flex-direction: row;
                border-right:none;
                box-shadow:none;
                padding: 0;
                z-index: 999;
            }
            .sidebar-links {
                flex-direction: row;
                width: auto;
            }
            .sidebar-links a {
                padding: 10px 10px;
                border-bottom: none;
                border-left: 3px solid transparent;
            }
            .sidebar-links a.active, .sidebar-links a:hover {
                border-left: 3px solid #a37c2c;
                border-bottom: none;
            }
            .sidebar-logout {
                width: auto; margin-top:0; padding: 0 0 0 10px;
            }
            .sidebar-logout button {
                padding:10px 22px; border-radius: 14px;
            }
            .admin-content {
                margin-left: 0;
                width: 100vw;
                min-width: unset;
            }
            .admin-header { margin-top: 20px;}
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <nav class="sidebar">
        <a href="admin.php?tab=album" class="sidebar-logo">A BRILLIANT VISION</a>
        <div class="sidebar-links">
            <a href="admin.php?tab=album" class="<?= ($tab === 'album') ? 'active' : '' ?>">Manage Album</a>
            <a href="admin.php?tab=bookings" class="<?= ($tab === 'bookings') ? 'active' : '' ?>">Client Booking</a>
            <a href="admin.php?tab=calendar" class="<?= ($tab === 'calendar') ? 'active' : '' ?>">Calendar</a>
            <a href="admin.php?tab=clients" class="<?= ($tab === 'clients') ? 'active' : '' ?>">Client Profile</a>
        </div>
        <div class="sidebar-logout">
            <form method="post" action="logout.php">
                <button type="submit" name="logout">Logout</button>
            </form>
        </div>
    </nav>
    <!-- Main Content -->
    <div class="admin-content">
        <?php if ($tab === 'album'): ?>
            <div class="admin-header">
                <h2>Admin Panel: Manage Album</h2>
                <div class="album-tabs">
                    <a href="admin.php?tab=album&album_tab=solo"><button class="album-tab-btn<?= ($albumTab === 'solo') ? ' active' : '' ?>">Solo Package</button></a>
                    <a href="admin.php?tab=album&album_tab=squad"><button class="album-tab-btn<?= ($albumTab === 'squad') ? ' active' : '' ?>">Squad Package</button></a>
                    <a href="admin.php?tab=album&album_tab=family"><button class="album-tab-btn<?= ($albumTab === 'family') ? ' active' : '' ?>">Family Package</button></a>
                </div>
                <div class="msg"><?= $msg ?></div>
                <form method="post" enctype="multipart/form-data" class="upload-form">
                    <input type="hidden" name="album_tab" value="<?= htmlspecialchars($albumTab) ?>">
                    <input type="file" name="photo" accept="image/*" required>
                    <button type="submit" name="upload">Upload Photo</button>
                </form>
            </div>
            <div class="album-photos-admin">
                <?php foreach($photos as $file): ?>
                    <div class="admin-photo-item">
                        <img src="<?= $curr_album_dir . $file ?>" alt="Album Photo">
                        <a href="admin.php?tab=album&album_tab=<?= htmlspecialchars($albumTab) ?>&del=<?= urlencode($file) ?>" class="delete-link" onclick="return confirm('Delete this photo?')">Delete</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($tab === 'bookings'): ?>
            <div class="admin-header">
                <h2>Client Booking</h2>
                <div class="msg"><?= $msg ?></div>
            </div>
            <div style="overflow-x:auto; max-width:1120px; margin:0 auto;">
                <?php if (count($bookings)): ?>
                    <table class="booking-table">
                        <tr>
                            <th>Package</th>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Notes</th>
                            <th>Booked At</th>
                            <th>Status / Action</th>
                            <th>Remove</th>
                        </tr>
                        <?php foreach (array_reverse($bookings, true) as $idx => $b): ?>
                        <tr>
                            <td><?=htmlspecialchars($b['package'])?></td>
                            <td><?=htmlspecialchars($b['date'])?></td>
                            <td><?=htmlspecialchars($b['name'])?></td>
                            <td><?=htmlspecialchars($b['email'])?></td>
                            <td><?=htmlspecialchars($b['phone'])?></td>
                            <td><?=nl2br(htmlspecialchars($b['notes']))?></td>
                            <td><?=htmlspecialchars($b['timestamp'])?></td>
                            <td>
                                <?php if (isset($b['confirmed']) && $b['confirmed']): ?>
                                    <span style="color:green;font-weight:600;">Confirmed</span>
                                <?php else: ?>
                                    <a href="admin.php?tab=bookings&confirm=<?=$idx?>" style="color:#008CBA; font-weight:600; text-decoration:none;" onclick="return confirm('Send confirmation email to this client?');">
                                        Confirm
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="admin.php?tab=bookings&remove=<?=$idx?>" onclick="return confirm('Remove this booking?')" style="color:#c24; font-weight:600; text-decoration:none;">Remove</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                <?php else: ?>
                    <div style="text-align:center;margin:60px 0 0 0;color:#a37c2c;">No bookings yet.</div>
                <?php endif; ?>
            </div>
        <?php elseif ($tab === 'calendar'): ?>
            <div class="admin-header">
                <h2>Calendar: Block Dates</h2>
                <div class="msg"><?= $msg ?></div>
                <form method="post" style="margin-bottom:18px;">
                    <label for="block_date" style="font-weight:500;">Block a date:</label>
                    <input type="date" id="block_date" name="block_date" required min="<?=date('Y-m-d')?>">
                    <button type="submit" style="padding:8px 20px;background:#a37c2c;color:#fff;border:none;border-radius:4px;cursor:pointer;">Block</button>
                </form>
                <div style="max-width:400px;margin:0 auto;">
                    <h4>Blocked Dates (manual):</h4>
                    <?php if ($blocked_dates): ?>
                        <ul class="blocked-list" style="list-style:none;padding:0;">
                        <?php foreach ($blocked_dates as $d): ?>
                            <li>
                                <?=htmlspecialchars($d)?>
                                <a href="admin.php?tab=calendar&unblock=<?=urlencode($d)?>" style="color:#c24; text-decoration:none; font-weight:600; margin-left:15px;" onclick="return confirm('Unblock this date?')">Unblock</a>
                            </li>
                        <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div style="color:#a37c2c;">No blocked dates.</div>
                    <?php endif; ?>

                    <h4 style="margin-top:35px;">Booked Dates (auto-disabled):</h4>
                    <?php
                        $booked_dates = [];
                        foreach ($bookings as $b) {
                            if (!empty($b['date'])) $booked_dates[] = $b['date'];
                        }
                        $booked_dates = array_unique($booked_dates);
                    ?>
                    <?php if ($booked_dates): ?>
                        <ul class="blocked-list" style="list-style:none;padding:0;">
                        <?php foreach ($booked_dates as $bd): ?>
                            <li style="color:#232323;"><?=htmlspecialchars($bd)?></li>
                        <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div style="color:#a37c2c;">No booked dates yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif ($tab === 'clients'): ?>
            <div class="admin-header">
                <h2>Client Profiles</h2>
                <div class="msg"><?= $msg ?></div>
                <div style="max-width: 530px; margin: 0 auto 40px auto;">
                    <p style="color: #666;">Below is a list of all unique clients who booked a session.</p>
                    <input type="text" id="clientSearch" onkeyup="filterClientProfiles()" placeholder="Search by name, email, or phone..." style="margin:20px auto 0 auto;display:block;width:100%;max-width:350px;padding:9px 12px;font-size:1em;border:1.5px solid #a37c2c;border-radius:6px;">
                </div>
            </div>
            <div style="overflow-x:auto; max-width:650px; margin:0 auto;">
                <?php
                    $clients = [];
                    foreach ($bookings as $b) {
                        $key = strtolower(trim($b['email']));
                        if (!empty($key) && !isset($clients[$key])) {
                            $clients[$key] = [
                                'name' => $b['name'] ?? '',
                                'email' => $b['email'],
                                'phone' => $b['phone'] ?? '',
                            ];
                        }
                    }
                ?>
                <?php if (count($clients)): ?>
                    <table class="booking-table" id="clientProfilesTable">
                        <tr>
                            <th>#</th>
                            <th>Client Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Copy</th>
                        </tr>
                        <?php $i=1; foreach ($clients as $c): ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= htmlspecialchars($c['name']) ?></td>
                            <td><span class="client-email"><?= htmlspecialchars($c['email']) ?></span></td>
                            <td><?= htmlspecialchars($c['phone']) ?></td>
                            <td>
                                <button onclick="copyEmail('<?= htmlspecialchars($c['email']) ?>')" style="padding:4px 11px; background:#a37c2c; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:.97em;">Copy</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                <?php else: ?>
                    <div style="text-align:center;margin:60px 0 0 0;color:#a37c2c;">No clients yet.</div>
                <?php endif; ?>
            </div>
            <script>
            function copyEmail(email) {
                navigator.clipboard.writeText(email).then(function() {
                    alert('Email copied: ' + email);
                });
            }
            function filterClientProfiles() {
                let input = document.getElementById('clientSearch');
                let filter = input.value.toLowerCase();
                let table = document.getElementById('clientProfilesTable');
                let trs = table.getElementsByTagName('tr');
                for (let i = 1; i < trs.length; i++) {
                    let tds = trs[i].getElementsByTagName('td');
                    let show = false;
                    for (let j = 1; j < 4; j++) {
                        if (tds[j] && tds[j].textContent.toLowerCase().indexOf(filter) > -1) show = true;
                    }
                    trs[i].style.display = show ? "" : "none";
                }
            }
            </script>
        <?php endif; ?>
    </div>
</body>
</html>
