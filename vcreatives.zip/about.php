<?php
session_start();
function navActive($file) {
    return (basename($_SERVER['PHP_SELF']) == $file) ? 'class="active"' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About | A Brilliant Vision</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
    :root {
        --main-bg: #fcfaf4;
        --accent: #232323;
        --grey: #efefef;
        --soft-grey: #f4f3ed;
        --headline: #232323;
        --highlight: #a37c2c;
        --border: #e1e1e1;
        --purple-grad1: #e5e4f3;
        --purple-grad2: #fae6ee;
        --card-radius: 18px;
    }
    html, body {
        margin: 0; padding: 0;
        background: var(--main-bg);
        color: var(--accent);
        font-family: 'Montserrat', Arial, sans-serif;
    }
    body { padding-top: 80px; }

    /* NAVBAR */
    .navbar {
        position: fixed;
        top: 0; left: 0;
        width: 100vw;
        z-index: 100;
        background: var(--main-bg);
        box-shadow: 0 2px 14px 0 rgba(60,60,80,0.08);
    }
    .nav-inner {
        max-width: 1280px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1.5em 3vw 1em 3vw;
    }
    .logo {
        font-size: 1.3em;
        color: var(--headline);
        font-weight: 600;
        letter-spacing: 2px;
        text-decoration: none;
        flex-shrink: 0;
    }
    .nav-links {
        display: flex;
        gap: 2.2em;
        list-style: none;
        margin: 0; padding: 0;
        flex-wrap: wrap;
    }
    .nav-links a {
        color: var(--accent);
        font-size: 1em;
        font-weight: 400;
        text-decoration: none;
        letter-spacing: .4px;
        padding: 3px 1px;
        position: relative;
        transition: color 0.16s;
        background: transparent;
    }
    .nav-links a::after {
        content: '';
        display: block;
        width: 0;
        height: 2px;
        background: var(--highlight);
        transition: width 0.21s;
        position: absolute;
        left: 0;
        bottom: 0;
    }
    .nav-links a.active,
    .nav-links a:hover {
        color: #a37c2c;
    }
    .nav-links a.active::after,
    .nav-links a:hover::after {
        width: 100%;
    }

    .section-title {
        font-size: 2em;
        font-weight: 600;
        color: var(--headline);
        margin: 54px 0 18px 0;
        text-align: center;
        letter-spacing: 1px;
    }
    .about-desc {
        font-size: 1.17em;
        color: var(--accent);
        max-width: 780px;
        margin: 0 auto 35px auto;
        line-height: 1.7;
        text-align: center;
    }
    .about-cards {
        display: flex;
        flex-wrap: wrap;
        gap: 36px;
        justify-content: center;
        margin-bottom: 42px;
    }
    .about-card {
        background: #f8f8f5;
        border-radius: var(--card-radius);
        box-shadow: 0 3px 18px rgba(0,0,0,0.05);
        padding: 32px 26px;
        min-width: 320px;
        max-width: 450px;
        margin-bottom: 16px;
        text-align: left;
        font-size: 1.08em;
        color: #444;
    }
    .about-card-title {
        font-size: 1.25em;
        color: var(--highlight);
        font-weight: bold;
        margin-bottom: 12px;
    }
    .team-section {
        max-width: 950px;
        margin: 0 auto 55px auto;
        padding: 20px 0 10px 0;
        background: none;
        box-shadow: none;
    }
    .team-list {
        display: flex;
        flex-wrap: nowrap;
        gap: 34px;
        justify-content: center;
        align-items: stretch;
        margin-bottom: 12px;
    }
    .team-member {
        background: #fff;
        border-radius: 18px;
        box-shadow: 0 3px 18px rgba(0,0,0,0.06);
        padding: 28px 15px 18px 15px;
        width: 205px;
        min-width: 170px;
        max-width: 210px;
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .team-photo {
        width: 90px;
        height: 90px;
        border-radius: 50%;
        object-fit: cover;
        background: #fff;
        margin-bottom: 13px;
        box-shadow: 0 2px 12px rgba(120,120,120,0.10);
        object-position: 50% 27%;
    }
    .team-photo.geneva { object-position: 50% 31%; }
    .team-photo.christian { object-position: 50% 19%; }
    .team-name {
        font-weight: 700;
        color: var(--accent);
        margin-bottom: 6px;
        font-size: 1.07em;
    }
    .team-role {
        font-size: .98em;
        color: #b79c60;
        margin-bottom: 0;
        line-height: 1.3;
    }
    @media (max-width: 950px) {
        .team-list { flex-wrap: wrap; gap: 16px;}
        .team-section { max-width: 99vw;}
        .about-cards { flex-direction: column; gap: 18px; }
    }
    @media (max-width: 600px) {
        .nav-inner { flex-direction: column; align-items: flex-start; padding: .7em .5em; }
        .nav-links { width: 100%; flex-wrap: wrap; gap: 1em;}
        .section-title { font-size: 1.27em; margin: 34px 0 14px 0;}
        .about-cards { flex-direction: column; gap: 14px; }
        .team-list { flex-direction: column; gap: 20px;}
        .team-member { width: 92vw; max-width: 300px;}
    }

    .footer {
        text-align: center;
        color: #a7a7a7;
        font-size: .98em;
        margin: 40px 0 15px 0;
    }
    </style>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="nav-inner">
            <a href="index.php" class="logo">A BRILLIANT VISION</a>
            <ul class="nav-links">
                <li><a href="index.php" <?=navActive('index.php')?>>Home</a></li>
                <li><a href="about.php" <?=navActive('about.php')?>>About</a></li>
                <li><a href="album.php" <?=navActive('album.php')?>>Album</a></li>
                <li><a href="login.php" <?=navActive('login.php')?>>Login</a></li>
            </ul>
        </div>
    </nav>

    <!-- Foundation in Faith -->
    <div class="section-title">Our Foundation in Faith</div>
    <div class="about-desc">
        At A Brilliant Vision, we believe that creativity is a gift from God. Every frame we capture is guided by our purpose to glorify Him through our work. <br>
        We see each project not just as a job, but as a divine opportunity to serve others with excellence, integrity, and love.<br>
        We offer our talents back to the One who gave them to us—committed to using photography as a vessel to reflect His beauty, joy, and light.
    </div>

    <!-- Company Overview -->
    <div class="section-title">Company Overview</div>
    <div class="about-desc">
        A Brilliant Vision is a creative photography studio that specializes in capturing the beauty of life’s moments—from joyful celebrations to quiet, meaningful milestones.<br>
        With a spirit of excellence and a heart rooted in purpose, we strive to deliver more than just beautiful images—we create visual stories that honor each person’s God-given uniqueness.
    </div>

    <!-- Life Verse -->
    <div class="about-cards">
        <div class="about-card">
            <div class="about-card-title">Our Life Verse</div>
            <div>
                May the favor of the Lord our God rest on us; establish the work of our hands for us—yes, establish the work of our hands. <br>
                <span style="color:#a37c2c; font-weight:500;">(Psalm 90:17)</span>
            </div>
        </div>
    </div>

    <!-- Mission and Vision -->
    <div class="about-cards">
        <div class="about-card">
            <div class="about-card-title">The Vision</div>
            To be a faith-driven creative studio that inspires and uplifts communities by turning personal stories into timeless images—crafted with heart, skill, and purpose.
        </div>
        <div class="about-card">
            <div class="about-card-title">The Mission</div>
            To glorify God by delivering creative, high-quality photography experiences that bring joy, preserve memories, and reflect the beauty of His creation in every person and moment we capture.
        </div>
    </div>

    <!-- Values -->
    <div class="section-title">Our Values</div>
    <div class="about-cards">
        <div class="about-card">
            <div class="about-card-title">Anchored in Faith</div>
            We honor God by letting our faith guide every part of our work. Through prayer and purpose, we seek to glorify Him in all we create.
        </div>
        <div class="about-card">
            <div class="about-card-title">Brilliance in Creativity</div>
            We pursue excellence by giving passion and care to every detail. Our goal is to bring each vision to life with originality and skill.
        </div>
        <div class="about-card">
            <div class="about-card-title">Value in Every Story</div>
            Every person and every moment we capture has meaning. We honor the uniqueness of each client by treating their stories with care, respect, and intention.
        </div>
    </div>

    <!-- Service Statement -->
    <div class="about-cards">
        <div class="about-card" style="max-width:600px;">
            <span style="font-style:italic; color:#a37c2c;">
            "At A Brilliant Vision, we simply aim to serve with heart. Through every photo, layout, and frame, we hope to reflect God’s beauty in your story—capturing moments not just for today, but for a lifetime."
            </span>
        </div>
    </div>

    <!-- Meet the Team -->
    <div class="section-title">Meet the Team</div>
    <div class="team-section">
        <div class="team-list">
            <div class="team-member">
                <img class="team-photo" src="von-abril.jpg" alt="Von Abril Cabingan">
                <div class="team-name">Von Abril Cabingan</div>
                <div class="team-role">Owner / Main Photographer & Editor</div>
            </div>
            <div class="team-member">
                <img class="team-photo geneva" src="geneva.jpg" alt="Geneva Cabingan">
                <div class="team-name">Geneva Cabingan</div>
                <div class="team-role">Marketing Manager</div>
            </div>
            <div class="team-member">
                <img class="team-photo christian" src="christian.jpg" alt="Christian Macalindong">
                <div class="team-name">Christian Macalindong</div>
                <div class="team-role">Assistant Photographer</div>
            </div>
        </div>
    </div>

    <!-- Contact & Social Links -->
    <div class="section-title">Find Us</div>
    <div class="about-cards">
        <div class="about-card" style="min-width:260px;">
            <span class="about-card-title" style="display:block;">Location</span>
            Meliora Bldg, Margarita St., Brgy. 7 Nasugbu, Batangas
        </div>
        <div class="about-card" style="min-width:260px;">
            <span class="about-card-title" style="display:block;">Facebook</span>
            <a href="https://fb.abrilliantvision.com" target="_blank">fb.abrilliantvision.com</a><br>
            <a href="https://fb.abvstudiocafe.com" target="_blank">fb.abvstudiocafe.com</a>
        </div>
        <div class="about-card" style="min-width:260px;">
            <span class="about-card-title" style="display:block;">Instagram</span>
            <a href="https://instagram.com/abrilliantvisionph" target="_blank">@abrilliantvisionph</a>
        </div>
    </div>

    <!-- Contact Us -->
    <div class="section-title">Contact Us</div>
    <div class="about-cards">
        <div class="about-card">
            <b>For clarifications and questions:</b><br><br>
            <b>Mailing Address:</b><br>
            Meleora Building, Margarita St., Brgy. 7 Nasugbu, Batangas<br><br>
            <b>Email:</b> abrilliantvision28@gmail.com<br>
            <b>Phone:</b> 09055931534
        </div>
    </div>

    <!-- FOOTER -->
    <div class="footer">
        &copy; <?=date('Y')?> A Brilliant Vision Studio. All Rights Reserved.
    </div>
</body>
</html>
